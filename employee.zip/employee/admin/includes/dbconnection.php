<?php
$con=mysqli_connect("Localhost", "root", "", "employee");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
